export const getStaticCDN = (path: string) => `${process.env.REACT_APP_PUBLIC_ARENT_DOMAIN}${path}`;
