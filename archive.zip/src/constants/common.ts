import { REACT_APP_PUBLIC_APP_ENV } from './env';

export const isProduction = REACT_APP_PUBLIC_APP_ENV === 'production';

export const LOCAL_STORAGE_KEYS = {};
